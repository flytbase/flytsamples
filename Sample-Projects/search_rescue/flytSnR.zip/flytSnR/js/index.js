var scouterIP, rescuerIP, scouterNamespace, rescuerNamespace, scouterWsPath, rescuerWsPath;
var scouterRos, rescuerRos, disconnectTimeout, scouterVideoIP, rescuerVideoIP;

var waypointsList=[];
var defaultAlt=5.0,defaultTime=0.0,defaultRadius=4.0,defaultOrbit=0.0,defaultYaw=0.0;
var map,lineScouter=[], lineRescuer=[];
var waypoint=[];
var currentLocationGCSScouter,currentLocationGCSRescuer;
var z1degScouter, z1degRescuer;
var infowindowScouter, infowindowRescuer;
var campSiteLocation=[], marker=[];
var infow=[], doneSite=[];
var rescuerDeployed=1;
var tagIDList=[];
var latOffset=0,longOffset=0, deployLatOffset=0, deployLongOffset=0;

$(document).ready(function(){

    function checkWidth(){
        $(".video-box").attr('style','top:'+(($(window).height()-400)/2)+'px;');
        $(".video-toggle").attr('style','top:'+(($(window).height()-100)/2)+'px;');
        $(".deploy-scouter-window").attr('style','left:'+(($(window).width()-300)/2)+'px;');
        $(".top-bar-bar").width($(".top-bar-bar").width()-190+"px");
        $("#gmap,.main-body").height($(window).height()-90+"px");
    }
    checkWidth();
    $(window).resize(checkWidth);
	try{

        currentLocationGCSScouter = new google.maps.Marker({draggable:true,position: new google.maps.LatLng(0, 0), icon: {path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW, scale: 5, anchor:new google.maps.Point(0, 1), fillColor: 'blue',strokeColor: 'blue',strokeWeight: 1, fillOpacity:1, rotation: z1degScouter  }});
		currentLocationGCSRescuer = new google.maps.Marker({draggable:true,position: new google.maps.LatLng(0, 0), icon: {path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW, scale: 5, anchor:new google.maps.Point(0, 1), fillColor: 'red',strokeColor: 'red',strokeWeight: 1, fillOpacity:1, rotation: z1degRescuer  }});
		

     	infowindowScouter = new google.maps.InfoWindow({
          content: "<strong>Scout</strong>"
        });

        infowindowRescuer = new google.maps.InfoWindow({
          content: "<strong>Rescuer</strong>"
        });

     	// infow1 = new google.maps.InfoWindow({
      //     content: "Camp Site 1"
      //   });

      //   infow2 = new google.maps.InfoWindow({
      //     content: "Camp Site 2"
      //   });
    	var myOptions = {zoom:15,center:new google.maps.LatLng(18.594,73.910),mapTypeId: google.maps.MapTypeId.ROADMAP ,disableDoubleClickZoom: true};
        map = new google.maps.Map(document.getElementById("gmap"), myOptions);

        // google.maps.event.addListener(map, 'dblclick', function(e){

        //     addWaypoints(e.latLng);
        // });

  //       google.maps.event.addListener(currentLocationGCSRescuer, 'click', function() {
		//    infowindowRescuer.open(map,currentLocationGCSRescuer);
		// });
		// infowindowScouter.open(map,currentLocationGCSScouter);
		// infowindowRescuer.open(map,currentLocationGCSRescuer);

		


    }
    catch(err) {

        $.gritter.add({
                    // (string | mandatory) the heading of the notification
                    title: 'No Internet Access ',
                    // (string | mandatory) the text inside the notification
                    text: 'Check Internet connection',
                    // (string | optional) the image to display on the left
                    image: 'images/favicon.png',
                    // (bool | optional) if you want it to fade out on its own or just sit there
                    sticky: false,
                    // (int | optional) the time you want it to be alive for before fading out
                    time: ''
                });
    }

});

$(".add-scouter").click(function(){

	$(".scouter-login-window").toggle(200);
});
$(".add-rescuer").click(function(){

	$(".rescuer-login-window").toggle(200);
});

$(".scouter-login").click(function(){
	scouterIP="https://"+$(".scouter-ip").val();
	scouterWsPath="wss://"+$(".scouter-ip").val();
	scouterVideoIP="http://"+$(".scouter-ip").val();
	login("scouter",scouterIP,$(".scouter-user").val(),$(".scouter-pass").val());

});
$(".rescuer-login").click(function(){
	// rescuerIP="https://"+$(".rescuer-ip").val();
	// rescuerWsPath="wss://"+$(".rescuer-ip").val();

	rescuerIP="http://"+$(".rescuer-ip").val()+":9090";
	rescuerWsPath="ws://"+$(".rescuer-ip").val()+":9090";

	rescuerVideoIP="http://"+$(".rescuer-ip").val();
	// login("rescuer",rescuerIP,$(".rescuer-user").val(),$(".rescuer-pass").val());
    getNamespace("rescuer");


});



function login(drone,ip,user,pass){
console.log(drone+" "+ip+" " +user+" "+pass);
    var msgdata={};
    msgdata['username']=user;
    msgdata['email']=user;
    msgdata['password']=pass;
    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify(msgdata),
        url: ip+"/login",
        success: function(data){


            if (data.response.errors){
                if (data.response.errors.email){

                    $.gritter.add({
		                 // (string | mandatory) the heading of the notification
		                 title: 'Login Failed!!',
		                 // (string | mandatory) the text inside the notification
		                 text: data.response.errors.email[0],
		                 // (string | optional) the image to display on the left
		                 image: 'images/favicon.png',
		                 // (bool | optional) if you want it to fade out on its own or just sit there
		                 sticky: false,
		                 // (int | optional) the time you want it to be alive for before fading out
		                 time: '5000'
		             });
                }else if(data.response.errors.password){

                    $.gritter.add({
		                 // (string | mandatory) the heading of the notification
		                 title: 'Login Failed!!',
		                 // (string | mandatory) the text inside the notification
		                 text: data.response.errors.password[0],
		                 // (string | optional) the image to display on the left
		                 image: 'images/favicon.png',
		                 // (bool | optional) if you want it to fade out on its own or just sit there
		                 sticky: false,
		                 // (int | optional) the time you want it to be alive for before fading out
		                 time: '5000'
		             });
                }

            }else{
            	if (drone=='scouter'){
        			sessionStorage.setItem('scouterToken',data.response.user.authentication_token);
            	}else{
        			sessionStorage.setItem('rescuerToken',data.response.user.authentication_token);
            	}
                getNamespace(drone);
            }

        },error:function(data){
        	$.gritter.add({
                 // (string | mandatory) the heading of the notification
                 title: 'Login Failed!!',
                 // (string | mandatory) the text inside the notification
                 text: 'Retry!!!!',
                 // (string | optional) the image to display on the left
                 image: 'images/favicon.png',
                 // (bool | optional) if you want it to fade out on its own or just sit there
                 sticky: false,
                 // (int | optional) the time you want it to be alive for before fading out
                 time: '5000'
             });
        }
    });

}


function getNamespace(drone){
	var token,restPath;

	if (drone=="scouter"){
		token=sessionStorage.getItem("scouterToken");
		restPath=scouterIP;
	}else{
		token=sessionStorage.getItem("rescuerToken");
		restPath=rescuerIP;
	}

    $.ajax({
        type: "GET",
        headers: { 'Authentication-Token': token },
        dataType: "json",
        contentType: "application/json",
        url: restPath+"/ros/get_global_namespace",
        success: function(data){

			if (drone=="scouter"){
				scouterNamespace=data.param_info.param_value;
				$(".scouter-login-window").hide();
				$(".status-label-scouter").show(200);
				$(".add-scouter").hide();
				$(".scouter-heading").show(200);

            	$(".messages").append("\n--  Scout Connected");
			}else{
				rescuerNamespace=data.param_info.param_value;
				$(".rescuer-login-window").hide();
				$(".status-label-rescuer").show(200);
				$(".add-rescuer").hide();
				$(".rescuer-heading").show(200);
            	$(".messages").append("\n--  Rescuer Connected");
			}
			rosInitialize(drone);

            // $(".messages").append("\n--  ");
// http://192.168.1.149:8080/stream?topic=/tag_detections_image&type=ros_compressed
        },
        error: function(){
        	setTimeout(function(){getNamespace(drone);},1000);
        }
    });
}


function rosInitialize(drone){
	var token,wsPath;
	if (drone=="scouter"){
		token=sessionStorage.getItem("scouterToken");
        wsPath=scouterWsPath;
	}else{
		token=sessionStorage.getItem("rescuerToken");
        wsPath=rescuerWsPath;
	}
    var ros = new ROSLIB.Ros({
      url : wsPath +'/websocket'
    });


    ros.on('connection', function() {
        console.log('Connected to websocket server.');
        setTimeout(function(){socketCallback(drone);},3000);

    });

    ros.on('error', function(error) {
      console.log('Error connecting to websocket server: ', error);
    });

    ros.on('close', function() {
      console.log('Connection to websocket server closed.');
    });

    var rauth = new ROSLIB.Message({
         "op": "auth",
         "mac" : token,

    });
	    ros.authenticate(rauth);
    

	if (drone=="scouter"){
		scouterRos=ros;
	}else{
		rescuerRos=ros;
	}

}

function socketCallback(drone){
	var ros,namespace;
	if (drone=="scouter"){
		ros=scouterRos;
		namespace=scouterNamespace;
	}else{
		ros=rescuerRos;
		namespace=rescuerNamespace;
	}

    var listenerBatteryStatus = new ROSLIB.Topic({
            ros :ros,
            name : '/'+namespace+'/mavros/battery',
            messageType : 'sensor_msgs/BatteryState',
            throttle_rate: 500
    });
    listenerBatteryStatus.subscribe(function(message) {
    	// console.log(drone+" "+message.voltage);
    	$("."+drone+"-battery-status").html("<i class='fa fa-bolt'> </i> "+round(message.voltage,2)+" V");
    	$("."+drone+"-battery-status").attr("style","border:2px solid yellow;");
    });


     var listenerGlobalPositionRaw = new ROSLIB.Topic({
            ros :ros,
            name : '/'+namespace+'/mavros/global_position/raw/fix',
            messageType : 'sensor_msgs/NavSatFix',
            throttle_rate: 1000
    });


    var gpsTimeout;
    listenerGlobalPositionRaw.subscribe(function(message) {

        if(gpsTimeout)clearTimeout(gpsTimeout);

        if(Math.sqrt(message.position_covariance[4])===0){

            $("."+drone+"-gps-status").html("<i class='fa fa-map-marker'> </i>  No GPS Lock");
            $("."+drone+"-gps-status").attr("style","border:2px solid red");

        }
        else if(Math.sqrt(message.position_covariance[4])<=5){
            $("."+drone+"-gps-status").html("<i class='fa fa-map-marker'> </i>  GPS Lock");
            $("."+drone+"-gps-status").attr("style","border:2px solid #2ecc71");

         }
         else{

            $("."+drone+"-gps-status").html("<i class='fa fa-map-marker'> </i>  No GPS Lock");
            $("."+drone+"-gps-status").attr("style","border:2px solid red");

         }

        gpsTimeout=setTimeout(function(){
            $("."+drone+"-gps-status").html("<i class='fa fa-map-marker'> </i>  No GPS");
            $("."+drone+"-gps-status").attr("style","border:2px solid grey");

        },2500);


    });



    var listenerState = new ROSLIB.Topic({
            ros :ros,
            name : '/'+namespace+'/flyt/state',
            messageType : 'mavros_msgs/State',
            throttle_rate: 200
    });


    listenerState.subscribe(function(message) {


		$("."+drone+"-connection-status").html("<i class='fa fa-heart'> </i>  Connected");
        $("."+drone+"-connection-status").attr("style","border:2px solid #2ecc71");

        clearTimeout(disconnectTimeout);
        disconnectTimeout=window.setTimeout(function(){

            $("."+drone+"-connection-status").html("<i class='fa fa-heart'> </i>  Disconnected");
            $("."+drone+"-connection-status").attr("style","border:2px solid red");


    		$("."+drone+"-battery-status").html("<i class='fa fa-bolt'> </i> 0 V");
    		$("."+drone+"-battery-status").attr("style","border:2px solid grey;");

            $("."+drone+"-gps-status").html("<i class='fa fa-map-marker'> </i>  No GPS");
            $("."+drone+"-gps-status").attr("style","border:2px solid grey");

            getNamespace(drone);


        },3000);

    });



   //  var listenerLocalPosition = new ROSLIB.Topic({
   //         ros :ros,
   //         name : '/'+namespace+'/mavros/local_position/local',
   //         messageType : 'geometry_msgs/TwistStamped',
   //         throttle_rate: 200
   // });


   // listenerLocalPosition.subscribe(function(message) {

   //         $('#posx').text(round(message.twist.linear.x,3));
   //         $('#posy').text(round(message.twist.linear.y,3));
   //         $('#posz').text(round(message.twist.linear.z,3));
   //         $('#velx').text(round(message.twist.angular.x,3));
   //         $('#vely').text(round(message.twist.angular.y,3));
   //         $('#velz').text(round(message.twist.angular.z,3));

   //         $('.top-bar-alt').text("Alt: "+round(message.twist.linear.z,3)*-1 + " m ");

   //      $('.alt-value').html("Alt: &nbsp;&nbsp;&nbsp;&nbsp;"+round(message.twist.linear.z,3)*(-1)+ " m ");
   // });


    var listenerGlobalPosition = new ROSLIB.Topic({
            ros :ros,
            name : '/'+namespace+'/mavros/global_position/global',
            messageType : 'sensor_msgs/NavSatFix',
            throttle_rate: 1000
    });

     var flagGCSScouter = 0;
     var flagGCSRescuer = 0;

    listenerGlobalPosition.subscribe(function(message) {
    	if (drone=="scouter"){
	        try{

		        var temp=new google.maps.LatLng(message.latitude,message.longitude);
		        if (flagGCSScouter){
		            draw(currentLocationGCSLatLngScouter,temp,'#0000AA',drone);
		        }
		 	    flagGCSScouter++;
		             //console.log(message.x);
		        currentLocationGCSLatLngScouter = new google.maps.LatLng(message.latitude,message.longitude);
		        currentLocationGCSScouter.setPosition(currentLocationGCSLatLngScouter);
	          	currentLocationGCSScouter.setIcon({path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,scale: 5, anchor:new google.maps.Point(0,1), fillColor: 'blue',strokeColor: 'blue',strokeWeight: 1, fillOpacity:1, rotation: z1degScouter } );

		     	currentLocationGCSScouter.setMap(map);
		     	infowindowScouter.open(map,currentLocationGCSScouter);

	     	}
	     	catch(err){}
     	}else{
     		try{

		        var temp=new google.maps.LatLng(message.latitude,message.longitude);
		        if (flagGCSRescuer){
		            draw(currentLocationGCSLatLngRescuer,temp,'#AA0000',drone);
		        }
		 	    flagGCSRescuer++;
		             //console.log(message.x);
		        currentLocationGCSLatLngRescuer = new google.maps.LatLng(message.latitude,message.longitude);
		        currentLocationGCSRescuer.setPosition(new google.maps.LatLng((currentLocationGCSLatLngRescuer.lat()+latOffset-deployLatOffset),(currentLocationGCSLatLngRescuer.lng()+longOffset-deployLongOffset)));
	          	currentLocationGCSRescuer.setIcon({path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,scale: 5, anchor:new google.maps.Point(0,1), fillColor: 'red',strokeColor: 'red',strokeWeight: 1, fillOpacity:1, rotation: z1degRescuer } );

		     	currentLocationGCSRescuer.setMap(map);
		     	infowindowRescuer.open(map,currentLocationGCSRescuer);
	     	}
	     	catch(err){}

     	}

     });


    var listenerAttitude = new ROSLIB.Topic({
            ros :ros,
            name : '/'+namespace+'/mavros/imu/data_euler',
            messageType : 'geometry_msgs/TwistStamped',
            throttle_rate: 100
    });

    listenerAttitude.subscribe(function(message){
    	if (drone=="scouter"){
        	z1degScouter = round(message.twist.linear.z,3) * 57.2958;
        }else{
        	z1degRescuer = round(message.twist.linear.z,3) * 57.2958;
        }
        
        

    });

    var distance=[], tagTimeout=[];
    if (drone=="scouter"){


	    var listenerAprilTag = new ROSLIB.Topic({
	            ros :ros,
	            name : '/camp_site_coordinates',
	            messageType : 'apriltags_ros/AprilTagCampSite',
	            throttle_rate: 100
	    })
	    listenerAprilTag.subscribe(function(message){console.log("printintg");
	    	var foundTag=0, we;
	    	for(we=0; we<tagIDList.length;we++){
	    		if(message.id==tagIDList[we]){
	    			foundTag=1;
	    			break;
	    		}
	    	}
	    	if(foundTag==0){
	    		tagIDList.push(message.id);
	    		doneSite[message.id]=0;
	    		distance[message.id]=0.25;
	    	}

	    	if (doneSite[message.id]==0){

	    		var temp=message.x_position*message.x_position+message.y_position*message.y_position;
		    	if (temp<distance[message.id]){
		    		distance[message.id]=temp;
                    campSiteLocation[message.id]=new google.maps.LatLng((currentLocationGCSLatLngScouter.lat()),(currentLocationGCSLatLngScouter.lng()));
                    
		    		clearTimeout(tagTimeout[message.id]);
			    	tagTimeout[message.id]=setTimeout(function(){console.log(temp);

						$(".messages").append("\n--  Camp Site "+(we+1)+"found. id:"+message.id);

			    		marker[message.id] = new google.maps.Marker({
						    position: new google.maps.LatLng(0, 0),
						    map: map,
						    title: 'CampSite '+(we+1)+'. id:'+message.id,

						    icon:'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld='+message.id+'|e74c3c|000000'
					  	});
			    		// campSiteLocation[message.id]=new google.maps.LatLng((currentLocationGCSLatLngScouter.lat()),(currentLocationGCSLatLngScouter.lng()));
		    			marker[message.id].setPosition(campSiteLocation[message.id]);
		    			marker[message.id].setMap(map);
				     	infow[message.id] = new google.maps.InfoWindow({
				          content: "Camp Site "+(we+1)+". id:"+message.id
				        });
		    			infow[message.id].open(map,marker[message.id]);
		    			doneSite[message.id]=1;

			    		 $.gritter.add({
			                 // (string | mandatory) the heading of the notification
			                 title: 'Camp site '+(we+1)+' found ',
			                 // (string | mandatory) the text inside the notification
			                 text: " Id:"+message.id,
			                 // (string | optional) the image to display on the left
			                 image: 'images/favicon.png',
			                 // (bool | optional) if you want it to fade out on its own or just sit there
			                 sticky: false,
			                 // (int | optional) the time you want it to be alive for before fading out
			                 time: '5000'
			             });
			             console.log(message.latitude+" "+message.longitude);
			             // console.log(rescuerDeployed+" "+parseInt($('.target-site-val').val()));
			            if (message.id==parseInt($('.target-site-val').val())){
                    console.log('calling rescuer for id:'+message.id);
			             	setTimeout(function(){deployRescuer(message.latitude,message.longitude);},1000);
		             	}
		             	rescuerDeployed++;


			    	},3000);
		    	}


	    	}


	    });
    }



}



function round(value,decimal){
    var x=Math.pow(10,decimal);
    return Math.round(value*x)/x;
}

$(".scouter-disconnect").click(function(){

	$(".status-label-scouter").toggle();
	$(".add-scouter").toggle(200);
	$(".scouter-heading").toggle();

})
$(".rescuer-disconnect").click(function(){

	$(".status-label-rescuer").toggle();
	$(".add-rescuer").toggle(200);
	$(".scouter-rescuer").toggle();

})

function draw(lat1,lat2,color,drone) {

    var flightPlanCoordinates = [
        lat1,
            lat2
    ];
    var flightPath = new google.maps.Polyline({
            path: flightPlanCoordinates,
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1.0,
            strokeWeight: 2
    });
    if (drone=='scouter'){
    	lineScouter.push(flightPath);
    }else{

    	lineRescuer.push(flightPath);
    }
    flightPath.setMap(map);
}

$(".deploy-scouter").click(function(){
    deployLatOffset=latOffset;
    deployLongOffset=longOffset;

	// $(".messages").append("\n--  Deploying Scout");
	var msgdata={};
	msgdata["app_name"]="surveyor.py";
	msgdata["arguments"]=parseFloat($(".dim1").val())+" "+parseFloat($(".dim2").val())+" "+parseFloat($(".step-val").val())+" "+parseFloat($(".height-val").val())+" True";

    $.ajax({
        type: "POST",
        headers: { 'Authentication-Token': sessionStorage.getItem('scouterToken') },
        dataType: "json",
        // contentType: "application/json",
        data: JSON.stringify(msgdata),
        url: scouterIP+"/ros/"+scouterNamespace+"/navigation/exec_script",
        success: function(data){console.log(data);

        	if (data.success){
				$(".deploy-scouter-window").toggle();

				$(".messages").append("\n--  Scout Deploying.");
	    		$.gritter.add({
	                 // (string | mandatory) the heading of the notification
	                 title: 'Scout Launched',
	                 // (string | mandatory) the text inside the notification
	                 text: '""',
	                 // (string | optional) the image to display on the left
	                 image: 'images/favicon.png',
	                 // (bool | optional) if you want it to fade out on its own or just sit there
	                 sticky: false,
	                 // (int | optional) the time you want it to be alive for before fading out
	                 time: '5000'
				});
        	}

        },error: function(data){
        	console.log(data);
        }

    });


});
function deployRescuer(lat,long){
    // console.log(lat+" "+long);
	
	// $(".messages").append("\n--  Deploying Rescuer");

	var msgdata={};
	msgdata["app_name"]="rescuer.py";
	msgdata["arguments"]=parseFloat((lat+latOffset))+" "+parseFloat((long+longOffset))+" 4.0  5";
    $.ajax({
        type: "POST",
        headers: { 'Authentication-Token': sessionStorage.getItem('scouterToken') },
        dataType: "json",
        // contentType: "application/json",
        data: JSON.stringify(msgdata),
        url: rescuerIP+"/ros/"+rescuerNamespace+"/navigation/exec_script",
        success: function(data){console.log(data);

        	if (data.success){
				// $(".deploy-scouter-window").toggle();
				$(".messages").append("\n--  Rescuer Deploying");

	    		$.gritter.add({
	                 // (string | mandatory) the heading of the notification
	                 title: 'Rescuer Launched',
	                 // (string | mandatory) the text inside the notification
	                 text: '""',
	                 // (string | optional) the image to display on the left
	                 image: 'images/favicon.png',
	                 // (bool | optional) if you want it to fade out on its own or just sit there
	                 sticky: false,
	                 // (int | optional) the time you want it to be alive for before fading out
	                 time: '5000'
				});
        	}

        },error: function(data){
        	console.log(data);
        }

    });


}
$(".video-toggle").click(function(){
	$(".video-box").html("<label class='video-heading'>Live Feed</label><button class='btn btn-primary btn-sm switch-rescuer-video'>Rescuer --></button><img style='z-index:1000;' id='image-box' src='"+scouterVideoIP+":8080/stream?topic=/tag_detections_image&type=ros_compressed&width=320&height=240' height=100% width=100%>");
	$(".video-box").toggle();
	// $("#img-box").attr("src",videoip+":8080/stream?topic=/tag_detections_image&type=ros_compressed");

});
$(".video-box").on('click','#image-box', function(){
// $("#image-box").click(function(){
	$(".video-box").toggle();
	$(".video-box").html("");

});




$(".clear-map").click(function(){
    for(var i=0;i<lineScouter.length;i++){
       lineScouter[i].setMap(null);
    }
    for(var j=0;j<lineScouter.length;j++){
       lineRescuer[j].setMap(null);
    }console.log(marker);
    for(var k=0;k<tagIDList.length;k++)marker[tagIDList[k]].setMap(null);

    campSiteLocation=[];
    marker=[];
    infow=[];
    doneSite=[];
    tagIDList=[];
    deployLatOffset=0;
    deployLongOffset=0;
    latOffset=0;
    longOffset=0;

});
$(".current-location").click(function(){

	map.panTo(currentLocationGCSLatLngScouter);
 	map.setZoom(21);
});
$(".deploy-scouter-window-button").click(function(){
	$(".deploy-scouter-window").toggle(200);
});


$(".video-box").on('click','.switch-rescuer-video', function(){
	$(this).siblings('#image-box').attr("src",rescuerVideoIP+":8080/stream?topic=/flytcam/detected_objects&type=ros_compressed");
	$(this).addClass("switch-scouter-video");
	$(this).html("Scout -->");
	$(this).removeClass("switch-rescuer-video");
});

$(".video-box").on('click','.switch-scouter-video', function(){
	$(this).siblings("#image-box").attr("src",scouterVideoIP+":8080/stream?topic=/tag_detections_image&type=ros_compressed");
	$(this).addClass("switch-rescuer-video");
	$(this).html("Rescuer -->");
	$(this).removeClass("switch-scouter-video");
});

$(".message-box, .message-toggle ").click(function(){
	$(".message-box").toggle();
});


$(".sync-gps").click(function(){

    latOffset=currentLocationGCSLatLngScouter.lat()-currentLocationGCSLatLngRescuer.lat();
    longOffset=currentLocationGCSLatLngScouter.lng()-currentLocationGCSLatLngRescuer.lng();
    console.log(latOffset+" "+longOffset);
})